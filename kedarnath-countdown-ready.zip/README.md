# Kedarnath Countdown

Ready-to-deploy static webpage. Target: **9 September 2026, 10:40 PM IST**.

## Deploy on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Settings → Pages → Deploy from branch → `main` / root.
4. Share the generated Pages link in WhatsApp.

The countdown uses the visitor device clock and the fixed IST target. The daily image/message rotates automatically.
